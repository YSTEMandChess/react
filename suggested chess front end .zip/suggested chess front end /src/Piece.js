const pieces = {
    r: '/pieces/bR.svg',
    n: '/pieces/bN.svg',
    b: '/pieces/bB.svg',
    q: '/pieces/bQ.svg',
    k: '/pieces/bK.svg',
    p: '/pieces/bP.svg',
    R: '/pieces/wR.svg',
    N: '/pieces/wN.svg',
    B: '/pieces/wB.svg',
    Q: '/pieces/wQ.svg',
    K: '/pieces/wK.svg',
    P: '/pieces/wP.svg',
  };
  
  export default pieces;
  